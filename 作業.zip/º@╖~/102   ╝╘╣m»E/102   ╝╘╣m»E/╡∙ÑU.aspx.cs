﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace _102___樊雋浩
{
    public partial class 註冊 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblMessage.Visible = false;
        }

        protected void FormView1_ItemInserting(object sender, FormViewInsertEventArgs e)
        {
            if (string.IsNullOrEmpty(e.Values["fName"].ToString()))
            {
                lblMessage.Visible = true;
                lblMessage.Text = "姓名是必填欄位";
                e.Cancel = true;
            }
        }

        protected void FormView1_ItemInserted(object sender, FormViewInsertedEventArgs e)
        {
            Response.Redirect("登入.aspx");
        }

        protected void FormView1_PageIndexChanging(object sender, FormViewPageEventArgs e)
        {

        }
    }
}