﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace _102___樊雋浩
{
    public partial class 登入 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Label1.Visible = false;
          

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            int pw = Convert.ToInt32(TextBox2.Text);
            tCustomer x = (new dbDemoDataContext()).tCustomer
                .FirstOrDefault(t => t.fEmail.Equals(
                    TextBox1.Text) && t.fId == pw);
            if (x != null)
            {
                Session[Class1.LOGIN_USER] = x;
                Response.Redirect("留言板.aspx");
            }
            Label1.Visible = true;
            Label1.Text = "帳號與密碼不符";
        }
    }
}