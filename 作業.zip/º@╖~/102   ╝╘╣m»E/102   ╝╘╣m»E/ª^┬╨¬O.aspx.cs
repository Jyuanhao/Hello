﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace _102___樊雋浩
{
    public partial class 回覆板 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string id = Request.QueryString["hid"];
            if (string.IsNullOrEmpty(id))
                Response.Redirect("留言板.aspx");
            SqlDataSource sds = new SqlDataSource();
            sds.ConnectionString = @"Data Source=.;Initial Catalog=XA;Integrated Security=True";
            sds.SelectCommand = "SELECT * FROM tHead WHERE fId=@KK ";
            sds.SelectParameters.Add("KK", id);
            DataView dv = sds.Select(DataSourceSelectArguments.Empty) as DataView;
            if (dv.Table.Rows.Count <= 0)
                Response.Redirect("留言板.aspx");
            Label1.Text = dv[0]["fSubject"].ToString();
        }

        protected void FormView1_PageIndexChanging(object sender, FormViewPageEventArgs e)
        {

        }

        protected void FormView1_ItemInserting(object sender, FormViewInsertEventArgs e)
        {
            string id = Request.QueryString["hid"];
            e.Values["fDate"] = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            e.Values["fHeadId"] = id;
        }
    }
}