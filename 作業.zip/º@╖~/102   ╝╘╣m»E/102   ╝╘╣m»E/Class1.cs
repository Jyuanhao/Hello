﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace _102___樊雋浩
{
    public class Class1
    {
        public static readonly string SHOPPINGCART_ITEMS_LIST = "SHOPPINGCART_ITEMS_LIST";
        internal static readonly string LOGIN_USER = "LOGIN_USER";
    }
}